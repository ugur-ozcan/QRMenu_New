﻿namespace QRMenu.Core.Enums
{
    public enum UserRole
    {
        Admin,
        DealerAdmin,
        CompanyAdmin
    }

}
