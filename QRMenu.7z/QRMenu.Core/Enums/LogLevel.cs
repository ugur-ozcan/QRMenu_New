﻿namespace QRMenu.Core.Enums
{
    public enum LogLevel
    {
        Info,
        Warning,
        Error,
        Critical
    }
}
