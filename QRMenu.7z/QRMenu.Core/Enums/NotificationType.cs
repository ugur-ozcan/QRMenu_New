﻿namespace QRMenu.Core.Enums
{
    public enum NotificationType
    {
        Email,
        Push,
        System
    }
}
