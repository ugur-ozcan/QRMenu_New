﻿namespace QRMenu.Core;

public class Class1
{

}
