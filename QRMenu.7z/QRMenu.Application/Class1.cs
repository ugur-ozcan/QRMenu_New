﻿namespace QRMenu.Application;

public class Class1
{

}
