﻿namespace QRMenu.Infrastructure;

public class Class1
{

}
